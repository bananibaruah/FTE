<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'mypass');
define('DB_NAME', 'jarvis');
 
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>



<!doctype html>


<html lang="en">
  <head>
  	<title>PIP) Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">PIP dashboard</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<h4 class="text-center mb-4"></h4>
					<div class="table-wrap">
						<table class="table">
					    <thead class="thead-primary">
					      <tr width="30px" height="30px">
							<th>List</th>
							<th>October 2021</th>
							<th>November 2021</th>
							<th>December 2021</th>
							<th>January 2022</th>
							<th>February 2022</th>
							<th>March 2022</th>
											  </tr>
					    </thead>
					    <tbody>
					      <tr>
					        <th scope="row" class="scope" >Count of Joinees (Active)</th>
<?php 


$link = mysqli_connect("localhost", "root", "mypass", "jarvis");
 
// Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    

    function gettotal($year) {

        $link = mysqli_connect("localhost", "root", "mypass", "jarvis");



        echo $year;
        
        $sql = "SELECT COUNT(Emp_Id) as total from pip WHERE YEAR(PIP_Start_Dt)='$year' ";

        if($result = mysqli_query($link, $sql)){

            while($row = mysqli_fetch_array($result)){

                    $total = $row['total'];

                    echo "active";
                    echo $total;

            }    
    
    
    }


    else{

        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

    }




return $total;


 }
      





$finalpc = gettotal("2020");
$finalpc = gettotal("2021");
$finalpc = gettotal("2022");


echo "<td>" . $finalpc. "</td>";


    // Close connection
    mysqli_close($link);



    ?>







					   