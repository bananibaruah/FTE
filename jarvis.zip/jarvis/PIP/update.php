<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>NSE-IT</title>


    <!-- bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <!-- progress barstle -->
    <link rel="stylesheet" href="css/css-circular-prog-bar.css">
    <!-- fonts style -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <!-- font wesome stylesheet -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" />
    <!-- responsive style -->
    <link href="css/responsive.css" rel="stylesheet" />



    <link rel="stylesheet" href="css/css-circular-prog-bar.css">

</head>

<body>
    <div class="top_container">
        <!-- header section strats -->
        <div class="container">
            <!--nav class="navbar navbar-expand-custom navbar-mainbg">
          <a class="navbar-brand navbar-logo" href="#"><img src="images/nseit.png" alt=""><span><img src="images/NSE.png" alt="" height="70px" width="180px"></span></a>
          <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fas fa-bars text-white"></i>
          </button>
          <div class=" navbar" id="navbarSupportedContent">
            <-a class="nav-link" href="javascript:void(0);"><i class="fas fa-tachometer-alt"></i>HOME</a>
            <a class="nav-link" href="javascript:void(0);"><i class="fas fa-tachometer-alt"></i>HOME</a>
          </div>
      <nav-->
            <div style="font-family:verdana;">

                <header>

                    <nav class="navbar navbar-light" style="background-color:#BFD7ED">

                        <div align=center>

                            <img src="NSE.png" height="35%" width="40%">

                        </div>

                    </nav>

                </header>

            </div>

        </div><br><br>
        <section class="hero_section ">
            <div class="hero-container container">
                <div class="hero_detail-box">
                    <!-- <h3>
                        Update your Record<br>
                    </h3> -->
                    <!-- <h1>
                        RECORD
                    </h1><br><br>
                    <div class="hero_btn-continer">
                        <a href="https://hr.nseit.com/jarvis/hrbp.php" class="call_to-btn btn_white-border">
                            <span>
                                BACK TO HOME
                            </span>
                            <img src="images/prev.png" alt="">
                        </a>
                    </div> -->
                </div>
                <div class="hero_img-container">
                    <div>
                        <?php

$LWD = $PIP_Start_Dt = $PIP_End_Dt = $Remark = $FinalStatus = $Comment = "";
$LWD_err = $PIP_Start_Dt_err = $PIP_End_Dt_err = $Remark_err = $FinalStatus_err = $Comment_err = "";

// Include config file
require_once "config.php";
// Define variables and initialize with empty values
// $LWD = $PIP_Start_Dt = $PIP_End_Dt = $Remark = $FinalStatus = $Comment ="";
// $LWD_err = $PIP_Start_Dt_err = $PIP_End_Dt_err =$Remark_err =$FinalStatus_err =$Comment_err = "";

if (isset($_POST["id"]) && !empty($_POST["id"])) {

    // $LWD = $PIP_Start_Dt = $PIP_End_Dt = $Remark = $FinalStatus = $Comment = "";
    // $LWD_err = $PIP_Start_Dt_err = $PIP_End_Dt_err = $Remark_err = $FinalStatus_err = $Comment_err = "";

    // Get hidden input value
    $id = $_POST["id"];
    $LWD = trim($_POST["LWD"]);
    $PIP_Start_Dt = trim($_POST["PIP_Start_Dt"]);
    $PIP_End_Dt = trim($_POST["PIP_End_Dt"]);
    $Remark = trim($_POST["Remark"]);
    $FinalStatus = filter_input(INPUT_POST, 'FS', FILTER_SANITIZE_STRING);
    $Comment = trim($_POST["Comment"]);
    // $AMT = trim($_POST["AMT"]);
    // $MMONTH = trim($_POST["MMONTH"]);
    // $CITATION = trim($_POST["CITATION"]);
    // $DDate = trim($_POST["DDate"]);
    // $BU = trim($_POST["BU"]);
    //   $RM = str_replace("'", "\'", $RM);
    //   $RM = str_replace("'", "\'", $RM);
    // echo $RM;

    // echo $LWD,$Project,$RM;
    $link = mysqli_connect("localhost", "root", "mypass", "jarvis");
    // Check connection
    if ($link === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $sql = "UPDATE pip SET LWD = '$LWD', PIP_Start_Dt ='$PIP_Start_Dt', PIP_End_Dt = '$PIP_End_Dt', Remark = '$Remark', FinalStatus = '$FinalStatus', Comment = '$Comment' WHERE Emp_Id = '$id';";
    // Attempt insert query execution
    if (mysqli_query($link, $sql)) {
        echo '<script>alert("Data Updated Successfully.")</script>';
        sleep(3);


    }
    else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
    // Close connection
    mysqli_close($link);


}
else {
    if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
        $id = trim($_GET["id"]);
        $sql = "SELECT * FROM pip WHERE Emp_Id = '$id' ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_id);
            $param_id = $id;
            if (mysqli_stmt_execute($stmt)) {
                $result = mysqli_stmt_get_result($stmt);
                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    // Retrieve individual field value
                    $LWD = $row["LWD"];
                    $PIP_Start_Dt = $row["PIP_Start_Dt"];
                    $PIP_End_Dt = $row["PIP_End_Dt"];
                    $Remark = $row["Remark"];
                    $FinalStatus = $row["FinalStatus"];
                    $Comment = $row["Comment"];
                // $Project = $row["Project"];
                // $RM = $row["RM"];
                // $FM = $row["FM"];
                // $DEPT = $row["DEPT"];
                // $TOA = $row["TOA"];
                // $AMT = $row["AMT"];
                // $MMONTH = $row["MMONTH"];
                // $CITATION = $row["CITATION"];
                // $DDate = $row["DDate"];
                // $BU = $row["BU"];
                }
                else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            }
            else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        // Close statement
        // mysqli_stmt_close($stmt);
        // Close connection
        mysqli_close($link);
    }
    else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}

echo $LWD;
?>
                        <link rel="stylesheet"
                            href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
                        <style>
                        .wrapper {
                            width: 600px;
                            margin: 0 auto;
                        }
                        </style>
                        <!-- <div class="wrapper">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12"> -->
                        <!-- <h2 class="mt-5"></h2>
                                        <p>
                                        <h6>Please update the input values and submit to update the employee record.
                                        </h6>
                                        </p> -->
                        <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                            <div class="container">
                                <div class="card" style=background-color:#BFD7ED>
                                    <div class="card-body">
                                        <b>
                                            <h6>
                                                <center>
                                                    Please update the input values and submit to update
                                                    the
                                                    employee record.
                                                </center>
                                            </h6>
                                        </b>
                                        <br />
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label>LWD</label>
                                                    <input type="date" textarea name="LWD"
                                                        class="form-control "><?php echo $LWD; ?></input>
                                                </div>
                                                <div class="form-group">
                                                    <label>PIP Start Date</label>
                                                    <input type="date" textarea name="PIP_Start_Dt"
                                                        class="form-control "><?php echo $PIP_Start_Dt; ?></input>
                                                </div>
                                                <div class="form-group">
                                                    <label>PIP End Date</label>
                                                    <input type="date" textarea name="PIP_End_Dt"
                                                        class="form-control "><?php echo $PIP_End_Dt; ?></input>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label>Remark</label>
                                                    <text name="Remarks"
                                                        class="form-control "><?php echo $Remark; ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    
                                                     <label>Final Status</label>
                                                        <select class="form-control" id="FS" name="FS">
                                                            <option value=""> </option>
                                                            <option value="Ongoing">Ongoing</option>
                                                            <option value="Successful Closure">Successful Closure</option>
                                                            <option value="NA - Resigned">NA- Resigned</option>
                                                            <option value="Unsuccessful Closure">Unsuccessful Closure</option>
                                                            <option value="Not initiated">Not initiated</option>
                                                            <option value="DCDC">DCDC</option>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <textarea name="Comment"
                                                        class="form-control "><?php echo $Comment; ?></textarea>
                                                </div>
                                            </div>
                                        </div>


                                        <input type="hidden" name="id" value="<?php echo $id; ?>" />
                                        <input type="submit" class="btn btn-primary" value="Submit">
                                        <a href="view.php" class="btn btn-secondary ml-2">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
        </section>
    </div>
    <!-- end header section -->


    <end landing section -->



        <!-- footer section -->
        <section class="container-fluid footer_section">
            <p>
                NSE-IT &copy; 2022 All Rights Reserved By
            </p>
        </section>
        <!-- footer section -->
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.js"></script>
        <script>
        // This example adds a marker to indicate the position of Bondi Beach in Sydney,
        // Australia.
        function initMap() {
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 11,
                center: {
                    lat: 40.645037,
                    lng: -73.880224
                },
            });
            var image = 'images/maps-and-flags.png';
            var beachMarker = new google.maps.Marker({
                position: {
                    lat: 40.645037,
                    lng: -73.880224
                },
                map: map,
                icon: image
            });
        }
        </script>
        <!-- google map js -->
        <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap">
        </script>
        <!-- end google map js -->
</body>

</html>
