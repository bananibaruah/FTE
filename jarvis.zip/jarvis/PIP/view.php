<?php

session_start();

function relax()
{
    ;
}
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../login.php");
    exit;


}

else {

    if ($_SESSION["roles"] == 5) {

        relax();
    }

    else {

        if ($_SESSION["roles"] == 1) {

            echo "you are not allowed to view this page!! return to attrition dashboard!!";



        }



        if ($_SESSION["roles"] == 2) {

            header("location: rview.php");

        }

        elseif ($_SESSION["roles"] == 3) {

            header("location: bgvview.php");

        }
    // echo $roles;

    }
}

$servername = 'localhost';
$username = 'root';
$password = 'mypass';
$dbname = 'jarvis';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {


    die('Could not Connect MySql Server:' . mysql_error());



}
?>


<!DOCTYPE html>


<html lang="en">
<style>
input[type=submit] {
    background-color: #009879;
    border: none;
    text-decoration: none;
    color: white;
    padding: 20px 20px;
    margin: 20px 20px;
    cursor: pointer;
}
</style>

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../style.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style> -->
    <script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
    </script>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">PIP Dashboard</h2>
                        <a href="../logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>


                        <?php
$sql = "SELECT * from pip";



// Attempt select query execution
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo '<table class="styled-table">';
        echo "<thead>";
        echo "<tr>";
        // echo "<th>#</th>";
        echo "<th>Emp Id</th>";

        echo "<th>Emp Name</th>";
        echo "<th>LWD</th>";
        echo "<th>Dept</th>";
        echo "<th>Grade</th>";
        echo "<th>RM</th>";
        echo "<th>FM</th>";

        echo "<th>HRBP</th>";

        echo "<th> PIP Start Date </th>";
        echo "<th> PIP End Date </th>";
        echo "<th> Remark </th>";
        echo "<th> Final Status </th>";
        echo "<th> Helper </th>";
        echo "<th> Comment </th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['Emp_Id'] . "</td>";

            echo "<td>" . $row['Emp_Name'] . "</td>";
            echo "<td>" . $row['LWD'] . "</td>";
            echo "<td>" . $row['Dept'] . "</td>";
            echo "<td>" . $row['Grade'] . "</td>";
            echo "<td>" . $row['RM'] . "</td>";

            echo "<td>" . $row['FM'] . "</td>";
            echo "<td>" . $row['HRBP'] . "</td>";
            echo "<td>" . $row['PIP_Start_Dt'] . "</td>";
            echo "<td>" . $row['PIP_End_Dt'] . "</td>";
            echo "<td>" . $row['Remark'] . "</td>";
            echo "<td>" . $row['FinalStatus'] . "</td>";
            echo "<td>" . $row['Helper'] . "</td>";
            echo "<td>" . $row['Comment'] . "</td>";

            echo "<td>";
            // echo '<a href="read.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
            echo '<a href="update.php?id=' . $row['Emp_Id'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-comment"></span></a>';
            // echo '<a href="delete.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        mysqli_free_result($result);
    }
    else {
        echo '<div class="alert alert-danger"><em>Please Select A Date range.</em></div>';
    }
}
else {
    echo "Oops! Something went wrong. Please try again later.";
}

// Close connection
mysqli_close($conn);
?>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>