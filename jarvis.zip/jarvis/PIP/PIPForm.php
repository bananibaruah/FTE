<?php
session_start();
 $servername = 'localhost';
 $username = 'root';
 $password = 'mypass';
 $dbname = 'jarvis';
 $conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
   
   
    die('Could not Connect MySql Server:' . mysql_error());
}


if (isset($_POST['submit'])) 
{
    $Emp_Id = $_POST['Emp_Id'];
    $Emp_Name = $_POST['Emp_Name'];
    $LWD= $_POST['LWD'];
    $Dept = $_POST['Dept'];
    $Grade = $_POST['Grade'];
    $RM = $_POST['RM'];
    $FM= $_POST['FM'];
    $HRBP = $_POST['HRBP'];
    $PIP_Start_Dt = $_POST['pips'];
    $PIP_End_Dt = $_POST['PIP_End_Dt'];
    $Remark = $_POST['Remark'];
    $FinalStatus= $_POST['FinalStatus'];
    $Helper= $_POST['Helper'];
    $Comment = $_POST['Comment'];

    
    
   $sql= "INSERT INTO `pip` (`Emp_Id`, `Emp_Name`, `LWD`, `Dept`, `Grade`, `RM`, `FM`, `HRBP`, `PIP_Start_Dt`, `PIP_End_Dt`, `Remark`, `FinalStatus`, `Helper`, `Comment`) VALUES ('$Emp_Id', '$Emp_Name', '$LWD', '$Dept', '$Grade', '$RM', '$FM', '$HRBP', '$PIP_Start_Dt', '$PIP_End_Dt', '$Remark', '$FinalStatus', '$Helper', '$Comment')";
                 

        
    
        // $sql = "INSERT INTO pip` (`Emp_Id`, `Emp_Name`, `LWD`, `Dept`, `Grade`,`RM`, `FM`, `HRBP`, `PIP_Start_Dt`, `PIP_End_Dt`, `Remark`, `FinalStatus` , `Helper`,'Comment')
        // VALUES ('$Emp_Id', '$Emp_Name', '$LWD', '$Dept', '$Grade','$RM', '$FM', '$HRBP', '$PIP_Start_Dt', '$PIP_End_Dt','$Remark', '$FinalStatus', '$Helper', '$Comment')";
    
        

       

    // $view = 'view.php';
    if(mysqli_query($conn, $sql)){
        echo "Records inserted successfully.";
        header("location: view.php");

        } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
        }
                        // Close connection
                mysqli_close($conn);
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    
    <style type="text/css">
    .wrapper 
    {
        width: 500px;
        margin: 0 auto;
    }
    #nav
    {
        background : #0056b3;
    }
    </style>

</head>
<body >
    <div style="font-family:verdana;">
        <header>
        <nav class="navbar navbar-light" style="background-color:#60A3D9" >
      <!-- <img src="NSELOGO.png" width="10%" height="15%" align=left> -->
               
                    <div align=center>
                     <h1 >&nbsp;&nbsp;PIP Form&nbsp;&nbsp;</h1>
                    </div>
                       
        </nav>
        </header>
    <div>

        <div class="container">
            <div class="card" style=background-color:#BFD7ED>
                <div class="card-body">
                    <form class="control" method="post">
                    <div class="row">
                        <div class="col-lg-6">
                            <label>Emp Id</label>
                            <input type="text" name="Emp_Id" value=""  class="form-control">
                            <br/>
                            <label>Emp Name</label>
                            <input type="text" name="Emp_Name" value="" class="form-control">
                            <br/>
                            <label>Last Working Day</label>
                            <input type="Date" name="LWD" value="" class="form-control">
                            <br/>
                            <label>Department</label>
                            <select class="form-control" id="Dept" name="Dept">
                                <option value="">select Department </option>
                                <option value="">Administration</option>
                                <option value="">Application Modernisation : Practice</option>
                                <option value="">Business Operations</option>
                                <option value="">Business Operations : Business Support</option>
                                <option value="">Business Operations : Channel</option>
                                <option value="">Business Operations : Content</option>
                                <option value="">Business Operations : DEX Development</option>
                                <option value="">Business Operations : Exam Result Processingt</option>
                                <option value="">Business Operations : HO Operations</option>
                                <option value="">Business Operations : Production Support</option>
                                <option value="">Business Operations : Quality & Training</option>
                                <option value="">Business Operations : Regional IT</option>
                                <option value="">Business Operations : Regional Operations</option>
                                <option value="">Business Operations : Software Testing</option>
                                <option value="">Business Operations : Vigilance</option>
                                <option value="">Business Solutions</option>
                                <option value="">Business Solutions : Sales</option>
                                <option value="">CEO's Office</option>
                                <option value="">CEO's Office : Strategy</option>
                                <option value="">Delivery : CCS</option>
                                <option value="">Delivery : Infrastructure</option>
                                <option value="">DEX</option>
                                <option value="">Digital DeliveryGST</option>
                                <option value="">Digital Delivery : Application Modernisation</option>
                                <option value="">Digital Delivery : Business Excellence</option>
                                <option value="">Digital Delivery : Business Transformation</option>
                                <option value="">Digital Delivery : Data Analytics</option>
                                <option value="">Digital Delivery : Professional Services Group</option>
                                <option value="">Digital Sales</option>
                                <option value="">Finance & Accounts</option>
                                <option value="">Finance & Accounts : Accounts Payables</option>
                                <option value="">Finance & Accounts : Accounts Receivables</option>
                                <option value="">Finance & Accounts : GST</option>
                                <option value="">Finance & Accounts : MIS</option>
                                <option value="">Finance & Accounts : Payroll</option>
                                <option value="">HO Operations : Core</option>
                                <option value="">HO Operations : Gateway</option>
                                <option value="">Human Resource Department</option>
                                <option value="">Human Resource Department : Service Delivery</option>
                                <option value="">Human Resource Department : Talent Acquisition</option>
                                <option value="">Legal & Secretarial</option>
                                <option value="">NSEIT</option>
                                <option value="">Technology & Innovation</option>
                                <option value="">Technology & Innovation : IT & Infra</option>
                                <option value="">Technology & Innovation : RMG</option>
                                <option value="">Technology & Innovation : Tech Solutions Group</option>
                            </select>
                            <br/>    
                            <label>Grade</label>
                            <select class="form-control" id="Gd" name="Grade">
                                    <option value="">Grade<option>
                                    <option value="">E40<option>
                                    <option value="">S10<option>
                                    <option value="">M30<option>
                                    <option value="">E20<option>
                                    <option value="">CON<option>
                                    <option value="">L10<option>
                                    <option value="">M20<option>
                                    <option value="">L16<option>
                                    <option value="">L15<option>
                                    <option value="">E11<option>
                                    <option value="">M10<option>
                                    <option value="">E30<option>
                                    <option value="">E10<option>
                                    <option value="">F00<option>
                                    <option value="">E21<option>
                                    <option value="">C10<option>
                                    <option value="">L11<option>
                                    <option value="">L20<option>
                                    <option value="">CEO<option>
                                    <option value="">EVC<option>
                                    <option value="">L30<option>
                                </select>
                            <br/>
                            <label>Reporting Manager</label></label>
                            <select class="form-control" id="RM" name="RM">
                                <option value="">Select Reporting Manager </option>
                                <option value="">Sanjay Bhavnani (03965) </option>
                                <option value="">Nandkumar M (00003) </option>
                                <option value="">Pratap Arni Mallisetty (04101) </option>
                                <option value="">Manish Chaturvedi (04095) </option>
                                <option value="">Sameer Salgaonkar (04078) </option>
                                <option value="">Samir Kulkarni (00191) </option>
                                <option value="">Mathew Joseph (C458) </option>
                                <option value="">Hirenkumar Bhatt (05255) </option>
                                <option value="">Ketan Vinodrai Parajia (04642) </option>
                                <option value="">Sripriya Suresh (05092) </option>
                                <option value="">Riten Jagadish Thacker (02185) </option>
                                <option value="">Vinay Arvindrao Wankhede (03799) </option>
                                <option value="">Ribhudeb Bhattacharya (02067) </option>
                                <option value="">Swarup Krishna Bose (03912) </option>
                                <option value="">Dennis Joe Christopher David (02248) </option>
                                <option value="">Santosh (00061) </option>
                                <option value="">Atul Rambhau Chaudhari (03708) </option>
                                <option value="">Karthikeyan A (03480) </option>
                                <option value="">Hariharan Manjeri Narayanan (03907) </option>
                                <option value="">Jayesh Ramaya Devadiga (00119) </option>
                                <option value="">Yogita Dere (00028) </option>
                                <option value="">Santosh Shankar Manchal (04243) </option>
                                <option value="">Nitin Madhaorao Gundawar (05062) </option>
                                <option value="">Jagadish M (02023) </option>
                                <option value="">Sumeet Batra (00005) </option>
                                <option value="">K.K. Shanoj Kumar (00097) </option>
                                <option value="">Avadhut Narsinha Gharat (00632) </option>
                                <option value="">Payal Vikas Pahwa (04340) </option>
                                <option value="">Krishnan Subramanian (04848) </option>
                                <option value="">Ravi Kiran M (00257) </option>
                                <option value="">Chintan M Turki (03917) </option>
                                <option value="">Ravishanker Pazhayanur Ramachandran (00942) </option>
                                <option value="">Beki Sunil (02424) </option>
                                <option value="">Vaidehi Pawar (00099) </option>
                                <option value="">Sarmistha Chakraborty Chakraborty (04064) </option>
                                <option value="">Sanu Thomas (03865) </option>
                                <option value="">Sankara Narayanan Subramaniam (02896) </option>
                                <option value="">Apoorva Ghanshyam Das Arora (04784) </option>
                                <option value="">Viresh Patel (00375) </option>
                                <option value="">Aniket Kumar Singh (00543) </option>
                                <option value="">Ashay Sudhakar Deshpande (04345) </option>
                                <option value="">Hitesh Aroda (00478) </option>
                                <option value="">Reema Sarki (04931) </option>
                                <option value="">Peter Simon Joseph (02979) </option>
                                <option value="">Balasubramanian V S (02146) </option>
                                <option value="">Mahesh Kumar (00406) </option>
                                <option value="">Rimamoni Borah (04978) </option>
                                <option value="">Dr. Pareshnath Paul (04495) </option>
                                <option value="">Suhas Arvind Dingare (02298) </option>
                                <option value="">Narinder Singh (00486) </option>
                                <option value="">Ankush Shukla (00637) </option>
                                <option value="">Sundareshwaran Iyer (04141) </option>
                                <option value="">Montu Surati (00120) </option>
                                <option value="">Nikhat Anjum Shaikh (F0739) </option>
                                <option value="">Nilesh Saxena (F0744) </option>
                                <option value="">Chandra Badan Mishra (05013) </option>
                                <option value="">Manoj Kumar (01071) </option>
                                <option value="">Chintaman Pandharinath Sanap (00716) </option>
                                <option value="">Tina Mathew (03690) </option>
                                <option value="">Raju Harilal Soni (03786) </option>
                                <option value="">Animesh Jha (00836) </option>
                                <option value="">Abhinav Singh (04332) </option>
                                <option value="">Amar Gochhait (00511) </option>
                                <option value="">Satish Kisan Shinde (01884) </option>
                                <option value="">Sumeet Nembhani (03527) </option>
                                <option value="">Krish Prajapati (03413) </option>
                                <option value="">Dipak Prakash Kasture (01676) </option>
                                <option value="">Mukesh Kumar (01625) </option>
                                <option value="">Amarjeet (00161) </option>
                                <option value="">Vishal N Patil (03119) </option>
                                <option value="">T Nithyanandham (F0754) </option>
                                <option value="">Sanjay Quadros (03350) </option>
                                <option value="">Sanjeev Krishnaraj Asher (05194) </option>
                                <option value="">Sumit Shukla (04631) </option>
                                <option value="">Vaibhav Padyal (00333) </option>
                                <option value="">Ketaki Ameya Bhagwat (03855) </option>
                                <option value="">N.A (N.A) </option>
                                <option value="">Manoj Cherian (05283) </option>
                                <option value="">Mayuresh Nirantar (05149) </option>
                                <option value="">Sudhir Waman Sawant (04168) </option>
                                <option value="">Satish Sharma (00159) </option>
                                <option value="">Bharat Pant (02940) </option>
                                <option value="">Vaibhhav Vijay Kulkarni (03920) </option>
                                <option value="">Arathi Chintan Ghatge (03406) </option>
                                <option value="">N Swaminathan (C444) </option>
                                <option value="">Vishal Doshi (00068) </option>
                                <option value="">Charles Prince H (03970) </option>
                                <option value="">Sandeep Krishna Naidu (03412) </option>
                                <option value="">Nitesh Bharat Bedi (03507) </option>
                                <option value="">Kaushik Kiran Mazumdar (00740) </option>
                                <option value="">Raman Sharma (00022) </option>
                                <option value="">Francy Chacko Thattil (03219) </option>
                                <option value="">Rucha Patil (03125) </option>
                                <option value="">Manojkumar Premshankar Kahar (03762) </option>
                                <option value="">Kaustubh Laturkar (04880) </option>
                                <option value="">Swarup Mitra (02504) </option>
                                <option value="">Sachin Ugale (00364) </option>
                                <option value="">Rajendra Purushottam Aparajit (04974) </option>
                                <option value="">Vijay Vilas Turkar (01987) </option>
                                <option value="">Paresh Narendra Mehta (04846) </option>
                                <option value="">Sachin R Bhagat (00859) </option>
                                <option value="">Ramchander Debu Ram Kumawat (02032) </option>
                                <option value="">Harvesp Shiavax Toorkey (01671) </option>
                                <option value="">Mangesh Sardesai (00012) </option>
                                <option value="">Manmohan Singh (03486) </option>
                                <option value="">Vidyut Vilas Jadhav (03765) </option>
                                <option value="">Hemal Narendra Shah (01306) </option>
                                <option value="">Devesh Ranjan (05159) </option>
                                <option value="">Prachi Karwatkar (00034) </option>
                                <option value="">Mahesh Arun Newalkar (04513) </option>
                                <option value="">Jeevika Perumal (03424) </option>
                                <option value="">Ujwala Amber Tambewagh (03394) </option>
                                <option value="">Nikhil Chande (00225) </option>
                                <option value="">Pravin Dindorkar (04510) </option>
                                <option value="">Sankar Pradhan (04416) </option>
                                <option value="">Victor Johnbritto (03294) </option>
                                <option value="">Sanket Rohit Upadhyay (05373) </option>
                                <option value="">Anantharaman Sreenivasan (04750) </option>
                                <option value="">Vishnu Soman (04893) </option>
                                <option value="">Supriyo Bhumendra Dutta (02406) </option>
                                <option value="">Satish Awadh Sharma (01760) </option>
                                <option value="">Aniket Bhikaji Vichare (03796) </option>
                                <option value="">Bharat Kumar Dayaramani (01794) </option>
                                <option value="">V Kumara Subramaniyan (F0695) </option>
                                <option value="">Ravindra Ramesh Sant (02182) </option>
                                <option value="">Nirnoy Sinha Chaudhuri (04175) </option>
                                <option value="">Vijay Tiwari (00681) </option>
                                <option value="">Ratnadeep Shrikrishna Nalavde (04938) </option>
                                <option value="">Vishant Kishore Mhadolkar (05073) </option>
                                <option value="">Ashok Reddy Yenumala (04706) </option>
                                <option value="">Karthikeyan M (03891) </option>
                                <option value="">Narasimha Prasad Badada (04093) </option>
                                <option value="">Ramkrishna Liladhar Asolkar (00746) </option>
                                <option value="">Swarnalatha Karukuri (04818) </option>
                                <option value="">Sujay Laxmeshwar (03361) </option>
                                <option value="">Kartik Srinivasan (05081) </option>
                                <option value="">Sathish R (F0622) </option>
                                <option value="">Sandip Patil (00254) </option>
                                <option value="">Vinay S Manjrekar (00149) </option>
                                <option value="">Sridharan P (F0738) </option>
                                <option value="">Richlyn Jerome Ferreira (03861) </option>
                                <option value="">Animesh Kumar Jha (00836) </option>
                                <option value="">Shyam Sundar G (04245) </option>
                                <option value="">Swapnil Arun Gholap (04369) </option>
                                <option value="">Ponnivalavan Chinnugoundar (04764) </option>
                                <option value="">Vishakha Yogesh Bhortake (04514) </option>
                                <option value="">Vinothkumar Swamidhanapal (04227) </option>
                                <option value="">Rukmini Panda (05055) </option>
                                <option value="">Punitha A (04398) </option>
                                <option value="">Sugham Bajirao Patil (02184) </option>
                                <option value="">Varghese Chacko Thoppil (00110) </option>
                                <option value="">Ajay Yadav (04976) </option>
                                <option value="">Jayesh Masand (01281) </option>
                                <option value="">Manoj Durgaprasad Varma (03069) </option>
                                <option value="">Akbar Ali Major (00133) </option>
                                <option value="">Purvi Shah (04714) </option>
                                <option value="">Sachin Deshpande (01253) </option>
                                <option value="">Akshay Vivek (04772) </option>
                                <option value="">Ancita Sonia Nazareth (04508) </option>
                                <option value="">Kalavati Suvarna (00002) </option>
                                <option value="">Jaysheel Hemant Dani (03879) </option>
                                <option value="">Seshasai M (05132) </option>
                                <option value="">Mangesh Mahadeo Patankar (04613) </option>
                                <option value="">Rajan Wadhwa (03822) </option>
                                <option value="">Rohini Shivaramaiah (04441) </option>
                                <option value="">Mahesh Belikatte (00917) </option>
                                <option value="">Mohammad Samiulla Khan (03547) </option>
                                <option value="">Pawan Yadav (03174) </option>
                                <option value="">Jagdish Palande (05141) </option>
                                <option value="">Prashant Chaudhary (04407) </option>
                                <option value="">Gomathi Krishnan Sankar (02560) </option>
                                <option value="">Mayur Narkhede (03234) </option>
                                <option value="">Shailesh Vasanji Surti (04713) </option>
                                <option value="">Vikram Mohanrao Salunkhe (05064) </option>
                                <option value="">Sameer Vinodchandra Mistry (C455) </option>
                                <option value="">Ajay R Kulkarni (04869) </option>
                                <option value="">Mohan Kumar (04170) </option>
                                <option value="">Motilal Satyarthi (04922) </option>
                                <option value="">Nakul Rajiv Deshpande (05080) </option>
                                <option value="">Sunil Harbhagwan Narsinghani (05004) </option>
                                <option value="">Usha Rudra Kumar (05272) </option>
                                <option value="">Gauri Bapu Dicholkar (01750) </option>
                                <option value="">Vinod Kishin Hingorani (05183) </option>
                                <option value="">Swapnil Suhas Deshpande (05082) </option>
                                <option value="">Vivek Vaidya (01018) </option>
                                <option value="">Nisha Nandakumar (02482) </option>
                                <option value="">Abhinav Chandra (05276) </option>
                                <option value="">Sudhir Kumar Shukla (05041) </option>
                                <option value="">Suraj Marathe (05182) </option>
                                <option value="">Hemantha Kumar Gummadi (03760) </option>
                                <option value="">R Krishnan (00039) </option>
                                <option value="">Venkatesh Ramchandran Iyer (05021) </option>
                                <option value="">Atul Pandurang Bhadange (05301) </option>
                                <option value="">Vinodh Palaniappan (05048) </option>
                                <option value="">Nitin Vinod Revaskar (04824) </option>
                                <option value="">Victor Johnbritto  (03294) </option>
                            </select>
                            <br/>
                            <label>Functional Manager</label>
                            <select class="form-control" id="FM" name="FM">
                                    <option value="">Select Functional Manager </option>
                                    <option value="">Sanjay Bhavnani (03965) </option>
                                    <option value="">Nandkumar M (00003) </option>
                                    <option value="">Pratap Arni Mallisetty (04101) </option>
                                    <option value="">Manish Chaturvedi (04095) </option>
                                    <option value="">Sameer Salgaonkar (04078) </option>
                                    <option value="">Samir Kulkarni (00191) </option>
                                    <option value="">Mathew Joseph (C458) </option>
                                    <option value="">Hirenkumar Bhatt (05255) </option>
                                    <option value="">Ketan Vinodrai Parajia (04642) </option>
                                    <option value="">Sripriya Suresh (05092) </option>
                                    <option value="">Riten Jagadish Thacker (02185) </option>
                                    <option value="">Vinay Arvindrao Wankhede (03799) </option>
                                    <option value="">Ribhudeb Bhattacharya (02067) </option>
                                    <option value="">Swarup Krishna Bose (03912) </option>
                                    <option value="">Dennis Joe Christopher David (02248) </option>
                                    <option value="">Santosh (00061) </option>
                                    <option value="">Atul Rambhau Chaudhari (03708) </option>
                                    <option value="">Karthikeyan A (03480) </option>
                                    <option value="">Hariharan Manjeri Narayanan (03907) </option>
                                    <option value="">Jayesh Ramaya Devadiga (00119) </option>
                                    <option value="">Yogita Dere (00028) </option>
                                    <option value="">Santosh Shankar Manchal (04243) </option>
                                    <option value="">Nitin Madhaorao Gundawar (05062) </option>
                                    <option value="">Jagadish M (02023) </option>
                                    <option value="">Sumeet Batra (00005) </option>
                                    <option value="">K.K. Shanoj Kumar (00097) </option>
                                    <option value="">Avadhut Narsinha Gharat (00632) </option>
                                    <option value="">Payal Vikas Pahwa (04340) </option>
                                    <option value="">Krishnan Subramanian (04848) </option>
                                    <option value="">Ravi Kiran M (00257) </option>
                                    <option value="">Chintan M Turki (03917) </option>
                                    <option value="">Ravishanker Pazhayanur Ramachandran (00942) </option>
                                    <option value="">Beki Sunil (02424) </option>
                                    <option value="">Vaidehi Pawar (00099) </option>
                                    <option value="">Sarmistha Chakraborty Chakraborty (04064) </option>
                                    <option value="">Sanu Thomas (03865) </option>
                                    <option value="">Sankara Narayanan Subramaniam (02896) </option>
                                    <option value="">Apoorva Ghanshyam Das Arora (04784) </option>
                                    <option value="">Viresh Patel (00375) </option>
                                    <option value="">Aniket Kumar Singh (00543) </option>
                                    <option value="">Ashay Sudhakar Deshpande (04345) </option>
                                    <option value="">Hitesh Aroda (00478) </option>
                                    <option value="">Reema Sarki (04931) </option>
                                    <option value="">Peter Simon Joseph (02979) </option>
                                    <option value="">Balasubramanian V S (02146) </option>
                                    <option value="">Mahesh Kumar (00406) </option>
                                    <option value="">Rimamoni Borah (04978) </option>
                                    <option value="">Dr. Pareshnath Paul (04495) </option>
                                    <option value="">Suhas Arvind Dingare (02298) </option>
                                    <option value="">Narinder Singh (00486) </option>
                                    <option value="">Ankush Shukla (00637) </option>
                                    <option value="">Sundareshwaran Iyer (04141) </option>
                                    <option value="">Montu Surati (00120) </option>
                                    <option value="">Nikhat Anjum Shaikh (F0739) </option>
                                    <option value="">Nilesh Saxena (F0744) </option>
                                    <option value="">Chandra Badan Mishra (05013) </option>
                                    <option value="">Manoj Kumar (01071) </option>
                                    <option value="">Chintaman Pandharinath Sanap (00716) </option>
                                    <option value="">Tina Mathew (03690) </option>
                                    <option value="">Raju Harilal Soni (03786) </option>
                                    <option value="">Animesh Jha (00836) </option>
                                    <option value="">Abhinav Singh (04332) </option>
                                    <option value="">Amar Gochhait (00511) </option>
                                    <option value="">Satish Kisan Shinde (01884) </option>
                                    <option value="">Sumeet Nembhani (03527) </option>
                                    <option value="">Krish Prajapati (03413) </option>
                                    <option value="">Dipak Prakash Kasture (01676) </option>
                                    <option value="">Mukesh Kumar (01625) </option>
                                    <option value="">Amarjeet (00161) </option>
                                    <option value="">Vishal N Patil (03119) </option>
                                    <option value="">T Nithyanandham (F0754) </option>
                                    <option value="">Sanjay Quadros (03350) </option>
                                    <option value="">Sanjeev Krishnaraj Asher (05194) </option>
                                    <option value="">Sumit Shukla (04631) </option>
                                    <option value="">Vaibhav Padyal (00333) </option>
                                    <option value="">Ketaki Ameya Bhagwat (03855) </option>
                                    <option value="">N.A (N.A) </option>
                                    <option value="">Manoj Cherian (05283) </option>
                                    <option value="">Mayuresh Nirantar (05149) </option>
                                    <option value="">Sudhir Waman Sawant (04168) </option>
                                    <option value="">Satish Sharma (00159) </option>
                                    <option value="">Bharat Pant (02940) </option>
                                    <option value="">Vaibhhav Vijay Kulkarni (03920) </option>
                                    <option value="">Arathi Chintan Ghatge (03406) </option>
                                    <option value="">N Swaminathan (C444) </option>
                                    <option value="">Vishal Doshi (00068) </option>
                                    <option value="">Charles Prince H (03970) </option>
                                    <option value="">Sandeep Krishna Naidu (03412) </option>
                                    <option value="">Nitesh Bharat Bedi (03507) </option>
                                    <option value="">Kaushik Kiran Mazumdar (00740) </option>
                                    <option value="">Raman Sharma (00022) </option>
                                    <option value="">Francy Chacko Thattil (03219) </option>
                                    <option value="">Rucha Patil (03125) </option>
                                    <option value="">Manojkumar Premshankar Kahar (03762) </option>
                                    <option value="">Kaustubh Laturkar (04880) </option>
                                    <option value="">Swarup Mitra (02504) </option>
                                    <option value="">Sachin Ugale (00364) </option>
                                    <option value="">Rajendra Purushottam Aparajit (04974) </option>
                                    <option value="">Vijay Vilas Turkar (01987) </option>
                                    <option value="">Paresh Narendra Mehta (04846) </option>
                                    <option value="">Sachin R Bhagat (00859) </option>
                                    <option value="">Ramchander Debu Ram Kumawat (02032) </option>
                                    <option value="">Harvesp Shiavax Toorkey (01671) </option>
                                    <option value="">Mangesh Sardesai (00012) </option>
                                    <option value="">Manmohan Singh (03486) </option>
                                    <option value="">Vidyut Vilas Jadhav (03765) </option>
                                    <option value="">Hemal Narendra Shah (01306) </option>
                                    <option value="">Devesh Ranjan (05159) </option>
                                    <option value="">Prachi Karwatkar (00034) </option>
                                    <option value="">Mahesh Arun Newalkar (04513) </option>
                                    <option value="">Jeevika Perumal (03424) </option>
                                    <option value="">Ujwala Amber Tambewagh (03394) </option>
                                    <option value="">Nikhil Chande (00225) </option>
                                    <option value="">Pravin Dindorkar (04510) </option>
                                    <option value="">Sankar Pradhan (04416) </option>
                                    <option value="">Victor Johnbritto (03294) </option>
                                    <option value="">Sanket Rohit Upadhyay (05373) </option>
                                    <option value="">Anantharaman Sreenivasan (04750) </option>
                                    <option value="">Vishnu Soman (04893) </option>
                                    <option value="">Supriyo Bhumendra Dutta (02406) </option>
                                    <option value="">Satish Awadh Sharma (01760) </option>
                                    <option value="">Aniket Bhikaji Vichare (03796) </option>
                                    <option value="">Bharat Kumar Dayaramani (01794) </option>
                                    <option value="">V Kumara Subramaniyan (F0695) </option>
                                    <option value="">Ravindra Ramesh Sant (02182) </option>
                                    <option value="">Nirnoy Sinha Chaudhuri (04175) </option>
                                    <option value="">Vijay Tiwari (00681) </option>
                                    <option value="">Ratnadeep Shrikrishna Nalavde (04938) </option>
                                    <option value="">Vishant Kishore Mhadolkar (05073) </option>
                                    <option value="">Ashok Reddy Yenumala (04706) </option>
                                    <option value="">Karthikeyan M (03891) </option>
                                    <option value="">Narasimha Prasad Badada (04093) </option>
                                    <option value="">Ramkrishna Liladhar Asolkar (00746) </option>
                                    <option value="">Swarnalatha Karukuri (04818) </option>
                                    <option value="">Sujay Laxmeshwar (03361) </option>
                                    <option value="">Kartik Srinivasan (05081) </option>
                                    <option value="">Sathish R (F0622) </option>
                                    <option value="">Sandip Patil (00254) </option>
                                    <option value="">Vinay S Manjrekar (00149) </option>
                                    <option value="">Sridharan P (F0738) </option>
                                    <option value="">Richlyn Jerome Ferreira (03861) </option>
                                    <option value="">Animesh Kumar Jha (00836) </option>
                                    <option value="">Shyam Sundar G (04245) </option>
                                    <option value="">Swapnil Arun Gholap (04369) </option>
                                    <option value="">Ponnivalavan Chinnugoundar (04764) </option>
                                    <option value="">Vishakha Yogesh Bhortake (04514) </option>
                                    <option value="">Vinothkumar Swamidhanapal (04227) </option>
                                    <option value="">Rukmini Panda (05055) </option>
                                    <option value="">Punitha A (04398) </option>
                                    <option value="">Sugham Bajirao Patil (02184) </option>
                                    <option value="">Varghese Chacko Thoppil (00110) </option>
                                    <option value="">Ajay Yadav (04976) </option>
                                    <option value="">Jayesh Masand (01281) </option>
                                    <option value="">Manoj Durgaprasad Varma (03069) </option>
                                    <option value="">Akbar Ali Major (00133) </option>
                                    <option value="">Purvi Shah (04714) </option>
                                    <option value="">Sachin Deshpande (01253) </option>
                                    <option value="">Akshay Vivek (04772) </option>
                                    <option value="">Ancita Sonia Nazareth (04508) </option>
                                    <option value="">Kalavati Suvarna (00002) </option>
                                    <option value="">Jaysheel Hemant Dani (03879) </option>
                                    <option value="">Seshasai M (05132) </option>
                                    <option value="">Mangesh Mahadeo Patankar (04613) </option>
                                    <option value="">Rajan Wadhwa (03822) </option>
                                    <option value="">Rohini Shivaramaiah (04441) </option>
                                    <option value="">Mahesh Belikatte (00917) </option>
                                    <option value="">Mohammad Samiulla Khan (03547) </option>
                                    <option value="">Pawan Yadav (03174) </option>
                                    <option value="">Jagdish Palande (05141) </option>
                                    <option value="">Prashant Chaudhary (04407) </option>
                                    <option value="">Gomathi Krishnan Sankar (02560) </option>
                                    <option value="">Mayur Narkhede (03234) </option>
                                    <option value="">Shailesh Vasanji Surti (04713) </option>
                                    <option value="">Vikram Mohanrao Salunkhe (05064) </option>
                                    <option value="">Sameer Vinodchandra Mistry (C455) </option>
                                    <option value="">Ajay R Kulkarni (04869) </option>
                                    <option value="">Mohan Kumar (04170) </option>
                                    <option value="">Motilal Satyarthi (04922) </option>
                                    <option value="">Nakul Rajiv Deshpande (05080) </option>
                                    <option value="">Sunil Harbhagwan Narsinghani (05004) </option>
                                    <option value="">Usha Rudra Kumar (05272) </option>
                                    <option value="">Gauri Bapu Dicholkar (01750) </option>
                                    <option value="">Vinod Kishin Hingorani (05183) </option>
                                    <option value="">Swapnil Suhas Deshpande (05082) </option>
                                    <option value="">Vivek Vaidya (01018) </option>
                                    <option value="">Nisha Nandakumar (02482) </option>
                                    <option value="">Abhinav Chandra (05276) </option>
                                    <option value="">Sudhir Kumar Shukla (05041) </option>
                                    <option value="">Suraj Marathe (05182) </option>
                                    <option value="">Hemantha Kumar Gummadi (03760) </option>
                                    <option value="">R Krishnan (00039) </option>
                                    <option value="">Venkatesh Ramchandran Iyer (05021) </option>
                                    <option value="">Atul Pandurang Bhadange (05301) </option>
                                    <option value="">Vinodh Palaniappan (05048) </option>
                                    <option value="">Nitin Vinod Revaskar (04824) </option>
                                    <option value="">Victor Johnbritto  (03294) </option>

                            </select>
                            
                        </div>
             
                        <div class="col-lg-6">
                            <label>HRBP</label>
                            <select class="form-control" id="HRBP" name="HRBP">
                                    <option value="">HRBP<option>
                                    <option value="">Rashmi Hiremath<option>
                                    <option value="">Karthikeyan M<option>
                                    <option value="">Gauri Dicholkar<option>
                                    <option value="">Rachna<option>
                                    <option value="">Srushti Jadhav<option>
                                    <option value="">Aditi Puri<option>
                                </select>
                            <br/>
                            <label>PIP Start Date</label>
                            <input type="Date" name="pips" value="" class="form-control">
                            <br/>
                            <label>PIP End Date</label>
                            <input type="Date" name="PIP_End_Dt" value="" class="form-control">
                            <br/>
                            <label>Remark</label>
                            <input type="text" name="Remark" value="" class="form-control">
                        
                            <br/>    
                            <label>Final Status</label>
                            <select class="form-control" id="FS" name="FinalStatus">
                            <option value=""> </option>
                            <option value="">Ongoing</option>
                            <option value="">Successful Closure</option>
                            <option value="">NA- Resigned</option>
                            <option value="">Unsuccessful Closure</option>
                            <option value="">Not initiated</option>
                            <option value="">DCDC</option>
                            </select>
                            <br/>
                            <label>Helper</label>
                            <input type="text" name="Helper" value="" class="form-control">
                            <br/>
                            <label>Comment</label>
                            <input type="text" name="Comment" value="" class="form-control">
                        </div>
                        <div class="col-lg-12" align = center>
                        </br>
                        </br>
                        <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                        </div>
                        </form>
                     </div>
            </div>
        </div>

</body>
</html>


