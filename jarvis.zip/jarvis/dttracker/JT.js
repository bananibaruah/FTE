let btn = document.getElementById('submitjt');
let toh = document.getElementById('toh');


btn.addEventListener('click', () => {

    let form = document.getElementById('JT');
    let etype = document.getElementById('etype').value;
    let ecode = document.getElementById('ecode').value;
    let econ = document.getElementById('econ').value;
    let egra = document.getElementById('egra').value;
    let eomail =  document.getElementById('eomail').value;
    let epmail =  document.getElementById('epmail').value;




if(eomail.endsWith("@nseit.com")){


    alert("ok")



}

else{
    alert("not ok")


}


    if (egra.startsWith("C") || egra.startsWith("E") || egra.startsWith("F") || egra.startsWith("L") || egra.startsWith("M") || egra.startsWith("S")) {


        alert("ok")
    }
    else {

        alert("Not ok")
    }


    if (etype == "PE") {

        if (ecode.length === 5) {

            if (ecode.charAt(0) === "0") {

                if (!isNaN(ecode)) {



                }
                else {

                    alert("PE Ecode Should be Numeric")

                }


            }
            else {

                alert("PE Ecode Starts with zero")
            }
        }

        else {

            alert("length should be five")
        }

    }

    if (etype == "FTE") {

        if (ecode.length === 5) {

            if (ecode.charAt(0) === "F") {

                if (ecode.charAt(1) === "0") {

                    if (!isNaN(ecode.slice(ecode.length - 3))) {



                    }
                    else {

                        alert("Last three digits should be numeric")

                    }

                }

                else (

                    alert("Second Letter of FTE Should be Zero")

                )



            }
            else {

                alert("FTE Ecode Starts with F")
            }
        }

        else {

            alert("length should be five")
        }

    }

    if (etype == "Consultant") {

        if (ecode.length === 4) {

            if (ecode.charAt(0) === "C") {



            }
            else {

                alert("Consultant Ecode Starts with C")
            }
        }

        else {

            alert("Length should be five")
        }

    }
    if (etype == "Intern") {

        if (ecode.length === 9) {

            if (ecode.startsWith("16")   // Returns true
            ) {

                if (!isNaN(ecode)) {



                }

                else {

                    alert("Ecode Should be numeric")
                }

            }

            else {


                alert("Ecode Starts with 16")
            }


        }

        else {

            alert("Length should be Nine")
        }

    }

    if (etype == "Temping") {

        if (ecode.length === 5) {

            if (ecode.charAt(0) === "T") {

                if (ecode.charAt(1) === "0") {

                    if (!isNaN(ecode.slice(ecode.length - 3))) {



                    }
                    else {

                        alert("Last three digits should be numeric")

                    }

                }

                else (

                    alert("Second Letter of Temping Ecode Should be Zero")

                )



            }
            else {

                alert("Temping Ecode Starts with T0")
            }
        }

        else {

            alert("length should be five")
        }

    }



})