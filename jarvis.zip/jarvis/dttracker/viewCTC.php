<?php


session_start(); // this NEEDS TO BE AT THE TOP of the page before any output etc

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "ctc" ;

// // Create connection
// $conn = new mysqli($servername, $username, $password , $dbname);



// // Check connection
// if ($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }
// echo "Connected successfully";










?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> CTC Breakup Calculator </title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     <style>
        table, th, td {
          border:0.000005px solid black;
        }
        </style>
  
   </head>
<body>
  <div class="container">


    <div class="title">Step 2 : Confirm CTC</div>
    <div class="content">
      <form action="GenerateOffer.html">
        <div class="user-details">

            <table  id= "tblCustomers" style="width:100%" cellspacing="0" cellpadding="0">
                <tr>
                  <th>Component </th>
                  <th>Percentage</th>
                  <th>Per Month</th>
                  <th>Per Annum</th>

                </tr>
                <tr>
                  <td>Basic Salary</td>
                  <td id="bpp"><?php echo $_SESSION['b'];?>%</td>
                  <td ><?php echo $_SESSION['eb']/12;?></td>
                  <td ><?php echo $_SESSION['eb'];?></td>

                </tr>
                <tr>
                  <td>House Rent Allowance</td>
                  <td id="bpp"><?php echo $_SESSION['h'];?>%</td>
                  <td ><?php echo $_SESSION['eh']/12;?></td>
                  <td ><?php echo $_SESSION['eh'];?></td>



                </tr>


                <tr>
                  <td>Dearness Allowance</td>
                  <td id="bpp"><?php echo $_SESSION['d'];?>%</td>
                  <td ><?php echo $_SESSION['ed']/12;?></td>
                  <td ><?php echo $_SESSION['ed'];?></td>



                </tr>
                <tr>
                  <td>Conveyance</td>
                  <td id="bpp"><?php echo $_SESSION['c'];?>%</td>
                  <td ><?php echo $_SESSION['ec']/12;?></td>
                  <td ><?php echo $_SESSION['ec'];?></td>



                </tr>

                <tr>
                  <td>Others</td>
                  <td id="bpp"><?php echo $_SESSION['o'];?>%</td>
                  <td ><?php echo $_SESSION['eo']/12;?></td>
                  <td ><?php echo $_SESSION['eo'];?></td>



                </tr>




  



              </table>
        </div>





        <div class="button">

          <!-- <input type="submit" value="Confirm Annexure"> -->


          <input type="button" id="btnExport" value="Confirm & Export" onclick="Export()" />







          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
          <script type="text/javascript">
              function Export() {
                  html2canvas(document.getElementById('tblCustomers'), {
                      onrendered: function (canvas) {
                          var data = canvas.toDataURL();
                          var docDefinition = {
                              content: [{
                                  image: data,
                                  width: 500
                
                              }]
                          };
                          pdfMake.createPdf(docDefinition).download("Table.pdf");
                      }
                  });
              }
          </script>
      
        </div>

        <div class="button">


            <input type="submit" id="gotooffer" value="Go to Step 3 , Enter Employee Details >>>" action="GenerateOffer.html"  />




        </div>
      </form>
    </div>
  </div>

</body>
</html>
