<div style="font-family:verdana;">

    <header>

        <nav class="navbar navbar-light" style="background-color:#BFD7ED">

            <div align=center>

                <img src="NSE.png" height="35%" width="40%">

            </div>

        </nav>

    </header>

</div>

<?php require_once("header.php"); ?>
<form method="post" action="data_upload.php">
    <div class="container">
        <div class="card" style=background-color:#BFD7ED>
            <div class="card-body">
                <b>
                    <h4>
                        <center>
                            FILL OUT THE RNR FORM TO UPDATE IN DATABASE
                        </center>
                    </h4>
                </b>
                <br />
                <div class="row">
                    <div class="col-lg-6">
                        <label="">Emp Id</label>
                            <input type="text" name="EMP_Id" class="form-control" placeholder="EMP_Id" />
                            <br />
                            <label="">Emp Name</label>
                                <input type="text" name="Emp_Name" class="form-control" placeholder="Emp_Name" />
                                <br />
                                <label="">Project</label>
                                    <input type="text" name="PROJECT" class="form-control" placeholder="PROJECT" />
                                    <br />
                                    <label="">RM</label>
                                        <input type="text" name="RM" class="form-control" placeholder="RM" />
                                        <br />
                                        <label="">FM</label>
                                            <input type="text" name="FM" class="form-control" placeholder="FM" />
                                            <br />
                                            <label="">Department</label>
                                                <input type="text" name="DEPT" class="form-control"
                                                    placeholder="DEPT" />
                                                <br />
                    </div>
                    <div class="col-lg-6">
                        <label="">TOA</label>
                            <input type="text" name="TOA" class="form-control" placeholder="TOA" />
                            <br />
                            <label="">AMOUNT</label>
                                <input type="text" name="AMT" class="form-control" placeholder="AMT" />
                                <br />
                                <label="">MONTH</label>
                                    <input type="text" name="MONTH" class="form-control" placeholder="MONTH" />
                                    <br />
                                    <label="">CITATION</label>
                                        <input type="text" name="CITATION" class="form-control"
                                            placeholder="CITATION" />
                                        <br />
                                        <label="">Date</label>
                                            <input type="date" name="Date" class="form-control" placeholder="Date" />
                                            <br />
                                            <label="">BU</label>
                                                <input type="text" name="BU" class="form-control" placeholder="BU" />
                                                <br />
                    </div>
                </div>
                <hr />
                <input type="submit" class="btn btn-primary" />
            </div>
        </div>
    </div>
</form>
<?php require_once("footer.php"); ?>