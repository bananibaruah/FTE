<?php require_once("config.php");

$EMP_Id = $_POST["EMP_Id"];
$Emp_Name = $_POST["Emp_Name"];
$PROJECT = $_POST["PROJECT"];
$RM = $_POST["RM"];
$FM = $_POST["FM"];
$DEPT = $_POST["DEPT"];
$TOA = $_POST["TOA"];
$AMT = $_POST["AMT"];
$MONTH = $_POST["MONTH"];
$CITATION = $_POST["CITATION"];
$Date = $_POST["Date"];
$BU = $_POST["BU"];
$ins_sql = "INSERT INTO rnr 
            (EMP_Id,Emp_Name,PROJECT,RM,FM,DEPT,TOA,AMT,MMONTH,CITATION,DDate,BU)
            VALUES
            (
                '$EMP_Id',
                '$Emp_Name',
                '$PROJECT',
                '$RM',
                '$FM',
                '$DEPT',
                '$TOA',
                 $AMT,
                '$MONTH',
                '$CITATION',
                '$Date',
                '$BU'
            )";
$link->query($ins_sql);
$sql = "SELECT MAX(EMP_Id) as rid FROM rnr";
$result = $link->query($sql);
$result->num_rows > 0;
$row = $result->fetch_assoc();
$id = $row["rid"];
header('Location:view.php?q=' . $id . '');
?>