<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<div style="font-family:verdana;">

    <header>

        <nav class="navbar navbar-light" style="background-color:#BFD7ED">

            <div align=center>

                <img src="NSE.png" height="35%" width="40%">

            </div>

        </nav>

    </header>

</div>

<?php require_once("header.php"); ?>
<div class="container-fluid">
    <a href="complete_view.php" class="btn btn-primary" style="float:right">Complete View</a>
    <br /><br />
    <b>
        <h3>
            <center>YOUR RNR DATA</center>
        </h3>
    </b>
    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <td>EMP_Id</td>
                <td>Emp_Name</td>
                <td>PROJECT</td>
                <td>RM</td>
                <td>FM</td>
                <td>DEPT</td>
                <td>TOA</td>
                <td>AMT</td>
                <td>MONTH</td>
                <td>CITATION</td>
                <td>Date</td>
                <td>BU</td>
                <td>Edit</td>


            </tr>
        </thead>
        <tbody>


            <?php
require_once("config.php");
$id = $_GET["q"];
echo $id;
//print_r($id);
$sql = "SELECT * FROM rnr WHERE EMP_Id = '$id'";
$result = $link->query($sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
?>
            <tr>
                <td><?php echo $row["EMP_Id"]; ?></td>
                <td><?php echo $row["Emp_Name"]; ?></td>
                <td><?php echo $row["PROJECT"]; ?></td>
                <td><?php echo $row["RM"]; ?></td>
                <td><?php echo $row["FM"]; ?></td>
                <td><?php echo $row["DEPT"]; ?></td>
                <td><?php echo $row["TOA"]; ?></td>
                <td><?php echo $row["AMT"]; ?></td>
                <td><?php echo $row["MMONTH"]; ?></td>
                <td><?php echo $row["CITATION"]; ?></td>
                <td><?php echo $row["DDate"]; ?></td>
                <td><?php echo $row["BU"]; ?></td>
                <td><?php echo '<a href="update.php?id=' . $row['EMP_Id'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-comment"></span></a>'; ?>
                </td>




            </tr>
            <?php
    }
}

else {


    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}



?>
        </tbody>
    </table>
</div>
<?php require_once("footer.php"); ?>