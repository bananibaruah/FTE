<?php

session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: index.php");
    exit;
}


require_once "../config.php";
ini_set('log_errors', 'Off');


// if(isset($_POST['search'])){



//     $fromd =  $_POST['from'];
//     $tod =  $_POST['to'];


//     $query= mysqli_query($link, "SELECT * from hrbpconnect WHERE LWD  BETWEEN '$fromd' AND '$tod' ORDER BY LWD DESC");
//     $count = mysqli_num_rows($query);
//     echo $count;

// }
?>


<!DOCTYPE html>


<html lang="en">
<style>
input[type=submit] {
    background-color: #0056b3;
    border: none;
    text-decoration: none;
    color: white;
    padding: 5px 5px;
    margin: 5px 5px;
    cursor: pointer;
}
</style>

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style> -->
    <script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
    </script>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid"><br>
            <img src="..\images\nselogo.png" height="100px" width="150px"><span></span>
            <h2>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp;

                <b>
                    <font color="#0056b3">ATTRITION DASHBOARD</font>
                </b>
            </h2>
            <div class="row">
                <div class="col-md-12">
                    <form method="post">
                        <label for="lwd">From </label>
                        <input type="date" name="from">
                        <label for="lwd">To </label>
                        <input type="date" name="to">
                        <input type="submit" name="search" value="Show Records">
                    </form>

                    <br>
                    <!-- <form>


                <input type="text"  placeholder="Enter Employee Name"  name="ename">
                        < <a ><i class="fa fa-search"></i> Search</a> -->
                    <!-- <input type="submit" name="sname" value="Show Records" > -->


                    <!-- </form>  -->
                    <?php
// Include config file
require_once "../config.php";


// if(empty($_POST['sname'])){

//     $ename="";

// }

// else{

//     $ename =  $_POST['ename'];

//     echo $ename;

// }


if (empty($_POST['search'])) {

    $fromd = "";
    $tod = "";

}

else {

    $fromd = $_POST['from'];
    $tod = $_POST['to'];

}
// echo $fromd,$tod;


if (empty($fromd)) {

    // echo "fromd null";

    if (empty($tod)) {

        // echo "tod null";
        $username = $_SESSION["username"];

        $admin = "admin@nseit.com";
        if (strcmp($username, $admin)) {

            $sql = "SELECT * from hrbpconnect  WHERE HRBP_Email = '$username'  ORDER BY LWD DESC ";



        }

        else {
            $sql = "SELECT * from hrbpconnect ORDER BY LWD DESC ";


        }



    }

}

else {

    $username = $_SESSION["username"];

    $sql = "SELECT * from hrbpconnect WHERE LWD  BETWEEN '$fromd' AND '$tod' AND HRBP_Email = '$username' ";

}



// Attempt select query execution
if ($result = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo '<table class="styled-table" class="feeze-table">';
        echo "<thead>";
        echo "<tr>";
        // echo "<th>#</th>";
        echo "<th>Employee Code</th>";

        echo "<th>Employee Name</th>";
        echo "<th>Location Name</th>";
        echo "<th>Grade</th>";
        echo "<th>Department </th>";
        echo "<th>Separation Status </th>";
        echo "<th>Last Working Day </th>";
        echo "<th>Resignation Status </th>";

        echo "<th>Gender </th>";
        echo "<th>HR SPOC </th>";
        echo "<th> Separation Reason </th>";
        echo "<th> Separation Sub Reason </th>";
        echo "<th> HRBP NomenClature </th>";
        echo "<th> HRBP Bucketing </th>";
        echo "<th> Remarks </th>";

        echo "<th> Edit </th>";

        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['EMPLOYEE_ID'] . "</td>";
            echo "<td>" . $row['EMPLOYEE_NAME'] . "</td>";
            echo "<td>" . $row['LOCATION_NAME'] . "</td>";
            echo "<td>" . $row['GRADE_NAME'] . "</td>";
            echo "<td>" . $row['DEPARTMENT_NAME'] . "</td>";
            echo "<td>" . $row['SEPARATION_STATUS'] . "</td>";

            echo "<td>" . $row['LWD'] . "</td>";
            echo "<td>" . $row['Resignation_Status'] . "</td>";
            echo "<td>" . $row['Gender'] . "</td>";
            echo "<td>" . $row['HR_SPOC'] . "</td>";
            echo "<td>" . $row['Seperation_Reason'] . "</td>";
            echo "<td>" . $row['Seperation_Sub_Reason'] . "</td>";
            echo "<td>" . $row['HRBP_Nomenclature'] . "</td>";
            echo "<td>" . $row['HRBP_Bucketing'] . "</td>";
            echo "<td>" . $row['Remarks'] . "</td>";
            echo "<td>";
            // echo '<a href="read.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
            echo '<a href="update.php?id=' . $row['EMPLOYEE_ID'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-comment"></span></a>';
            // echo '<a href="delete.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        mysqli_free_result($result);
    }
    else {
        echo '<div class="alert alert-danger"><em>Please Select A Date range.</em></div>';
    }
}
else {
    echo "Oops! Something went wrong. Please try again later.";
}

// Close connection
mysqli_close($link);
?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>