let btn = document.getElementById('submitjt');
let toh = document.getElementById('toh');


btn.addEventListener('click', () => {



    let frm = document.getElementById('JT');
    let Etype = document.getElementById('Etype').value;
    let Ecode = document.getElementById('Ecode').value;
    let Econ = document.getElementById('Econ').value;
    let Egra = document.getElementById('Egra').value;
    let Eomail = document.getElementById('Eomail').value;
    let Epmail = document.getElementById('Epmail').value;




    if (Eomail.endsWith("@nseit.com")) {



        var emailok = 1;


    }

    else {
        alert("Official Email should end with nseit.com")


    }


    if (Egra.startsWith("C") || Egra.startsWith("E") || Egra.startsWith("F") || Egra.startsWith("L") || Egra.startsWith("M") || Egra.startsWith("S")) {


        var gradeok=1;

    }
    else {

        alert("Please enter the proper Grade")
        
    }


    if (Etype == "PE") {

        if (Ecode.length === 5) {

            if (Ecode.charAt(0) === "0") {

                if (!isNaN(Ecode)) {


                    var Ecodeok = 1;

                }
                else {

                    alert("PE Ecode Should be Numeric")

                    


                }


            }
            else {

                alert("PE Ecode Starts with zero")
                
                

            }
        }

        else {

            alert(" Employee Code length should be five")
            
            

        }

    }

    if (Etype == "FTE") {

        if (Ecode.length === 5) {

            if (Ecode.charAt(0) === "F") {

                if (Ecode.charAt(1) === "0") {

                    if (!isNaN(Ecode.slice(Ecode.length - 3))) {

                        
                        var Ecodeok = 1;


                    }
                    else {

                        alert("Last three digits should be numeric")
                        
                        


                    }

                }

                else {

                    alert("SEcond Letter of FTE Should be Zero")


                    






                }



            }
            else {

                alert("FTE Ecode Starts with F")
                

            }
        }

        else {

            alert("length should be five")
            

        }

    }

    if (Etype == "Consultant") {

        if (Ecode.length === 4) {

            if (Ecode.charAt(0) === "C") {




var Ecodeok = 1;


            }
            else {

                alert("Consultant Ecode Starts with C")
                

            }
        }

        else {

            alert("Length should be five")
            

        }

    }
    if (Etype == "Intern") {

        if (Ecode.length === 9) {

            if (Ecode.startsWith("16")   // Returns true
            ) {

                if (!isNaN(Ecode)) {

var Ecodeok = 1;


                }

                else {

                    alert("Ecode Should be numeric")
                    

                }

            }

            else {


                alert("Ecode Starts with 16")
                

            }


        }

        else {

            alert("Length should be Nine")
            

        }

    }

    if (Etype == "Temping") {

        if (Ecode.length === 5) {

            if (Ecode.charAt(0) === "T") {

                if (Ecode.charAt(1) === "0") {

                    if (!isNaN(Ecode.slice(Ecode.length - 3))) {

                        var Ecodeok = 1;


                    }
                    else {

                        alert("Last three digits should be numeric")
                        


                    }

                }

                else {

                    alert("SEcond Letter of Temping Ecode Should be Zero")
                    


                    
                }



            }
            else {

                alert("Temping Ecode Starts with T0")
                
            }
        }

        else {

            alert("length should be five")
            
        }

    }


    console.log("final ok");


if(gradeok==1 && Ecodeok==1 && emailok==1){

    frm.submit()
}
else{

    alert("somethings not right dude.")
}
    


})