<?php

session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../index.php");


    exit;
}


else {
    if ($_SESSION["roles"] == 7){

               header("location: viewjtasdt.php");
    
       }
    }


require_once "../config.php";
ini_set('log_errors', 'Off');


// if(isset($_POST['search'])){



//     $fromd =  $_POST['from'];
//     $tod =  $_POST['to'];


//     $query= mysqli_query($link, "SELECT * from hrbpconnect WHERE LWD  BETWEEN '$fromd' AND '$tod' ORDER BY LWD DESC");
//     $count = mysqli_num_rows($query);
//     echo $count;

// }
?>


<!DOCTYPE html>


<html lang="en">
<style>

body {
  background-color: #ffffff;
}

input[type=submit] {
    background-color: #0056b3;
    border: none;
    text-decoration: none;
    color: white;
    padding: 5px 5px;
    margin: 5px 5px;
    cursor: pointer;
}
</style>

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style2.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style> -->
    <script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
    </script>
</head>

<body >
    <div class="wrapper">
        <div class="container-fluid"><br>
            <img src="..\images\nselogo.png" height="100px" width="150px"><span></span>
            <h2>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp;

                <b>
                    <font color="#0056b3">Joining Trackers</font>
                </b>
            </h2>
            <div class="row">
                <div class="col-md-12">
                    <form method="post">
                        <!-- <label for="lwd">From </label>
                        <input type="date" name="from">
                        <label for="lwd">To </label>
                        <input type="date" name="to"> -->
                        <input type="submit" name="search" value="Show Records">
                    </form>

                    <br>
                    <a href="addjt.php" > Add New Employee </a>

                    <!-- <form>

                <input type="text"  placeholder="Enter Employee Name"  name="ename">
                        < <a ><i class="fa fa-search"></i> Search</a> -->
                    <!-- <input type="submit" name="sname" value="Show Records" > -->


                    <!-- </form>  -->
                    <?php
// Include config file
require_once "../config.php";


// if(empty($_POST['sname'])){

//     $ename="";

// }

// else{

//     $ename =  $_POST['ename'];

//     echo $ename;



$sql = "SELECT * from jt ORDER BY Edoj DESC ";

// Attempt select query execution
if ($result = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo '<table class="styled-table" class="feeze-table">';
        echo "<thead>";
        echo "<tr>";
        echo "<th>	Ecode	</th>";
        echo "<th>	Edoj	</th>";
        echo "<th>	Efname	</th>";
        echo "<th>	Emname	</th>";
        echo "<th>	Elname	</th>";
        echo "<th>	Etype	</th>";
        echo "<th>	Dept	</th>";
        echo "<th>	Desig	</th>";
        echo "<th>	Location	</th>";
        echo "<th>	Ecli	</th>";
        echo "<th>	Erm	</th>";
        echo "<th>	Econ	</th>";
        echo "<th>	Erect	</th>";
        echo "<th>	Egra	</th>";
        echo "<th>	Eomail	</th>";
        echo "<th>	Epmail	</th>";
        echo "<th>	Epan	</th>";
        echo "<th>	Eaadh	</th>";
        echo "<th>	Edob	</th>";
        echo "<th>	Eskills	</th>";
        echo "<th>	Equal	</th>";
        echo "<th>	Eesic	</th>";
        echo "<th>	Eroles	</th>";
        
        echo "<th> Edit </th>";

        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['Ecode'] . "</td>";
            echo "<td>" . $row['Edoj'] . "</td>";
            echo "<td>" . $row['Efname'] . "</td>";
            echo "<td>" . $row['Emname'] . "</td>";
            echo "<td>" . $row['Elname'] . "</td>";
            echo "<td>" . $row['Etype'] . "</td>";
            echo "<td>" . $row['Dept'] . "</td>";
            echo "<td>" . $row['Desig'] . "</td>";
            echo "<td>" . $row['Location'] . "</td>";
            echo "<td>" . $row['Ecli'] . "</td>";
            echo "<td>" . $row['Erm'] . "</td>";
            echo "<td>" . $row['Econ'] . "</td>";
            echo "<td>" . $row['Erect'] . "</td>";
            echo "<td>" . $row['Egra'] . "</td>";
            echo "<td>" . $row['Eomail'] . "</td>";
            echo "<td>" . $row['Epmail'] . "</td>";
            echo "<td>" . $row['Epan'] . "</td>";
            echo "<td>" . $row['Eaadh'] . "</td>";
            echo "<td>" . $row['Edob'] . "</td>";
            echo "<td>" . $row['Eskills'] . "</td>";
            echo "<td>" . $row['Equal'] . "</td>";
            echo "<td>" . $row['Eesic'] . "</td>";
            echo "<td>" . $row['Eroles'] . "</td>";
                       echo "<td>";
            // echo '<a href="read.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
            echo '<a href="updatejt.php?id=' . $row['Ecode'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-comment"></span></a>';
            // echo '<a href="delete.php?EMPLOYEE_ID='. $row['EMPLOYEE_ID'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        mysqli_free_result($result);
    }
    else {
        echo '<div class="alert alert-danger"><em>Please Select A Date range.</em></div>';
    }
}
else {
    echo "Oops! Something went wrong. Please try again later.";
}

// Close connection
mysqli_close($link);
?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>