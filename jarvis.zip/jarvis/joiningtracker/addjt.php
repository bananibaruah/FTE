<!DOCTYPE html>
<html lang="en" dir="ltr">




<head>
    <meta charset="UTF-8">
    <title> Joining Tracker </title>
    <link rel="stylesheet" href="style.css">
</head>
<?php

require("../config.php");



$deptdd = "SELECT distinct dept from dependentlist ;";
$desgndd = "SELECT DISTINCT desgn from dependentlist;";
$locationdd = "SELECT DISTINCT Location_Name from locationsdd;";
$rmdd = "SELECT DISTINCT `COL 4` from l5mapping;";
$recdd = "SELECT DISTINCT `Recruiter_name` from recruitersdd;";
$clidd = "SELECT DISTINCT `Project_Name` from projectdd;";

$result = mysqli_query($link, $desgndd);

$desgn = "";

while($row = mysqli_fetch_array($result))
{
    $desgn = $desgn."<option>$row[0]</option>";
}



$result2 = mysqli_query($link, $deptdd);

$dept = "";

while($row = mysqli_fetch_array($result2))
{
    $dept = $dept."<option>$row[0]</option>";
}


$result3 = mysqli_query($link, $locationdd);

$location = "";

while($row = mysqli_fetch_array($result3)){
     $location = $location."<option>$row[0]</option>";
}


$result4 = mysqli_query($link, $rmdd);

$rm = "";

while($row = mysqli_fetch_array($result4)){
     $rm = $rm."<option>$row[0]</option>";
}

$result5 = mysqli_query($link, $recdd);

$rec = "";

while($row = mysqli_fetch_array($result5)){
     $rec = $rec."<option>$row[0]</option>";
}



$result6 = mysqli_query($link, $clidd);

$cli = "";

while($row = mysqli_fetch_array($result6)){
     $cli = $cli."<option>$row[0]</option>";
}


?>

<body>
    <div class="container">
        <div class="content">
            <form method="POST" action="submitjt.php" id="JT">
                <div class="user-details">
                    <div class="input-box">
                        <span class="details" for="Etype">Choose Employee Type:</span>

                        <select class="input-box" name="Etype" id="Etype">
                            <option value="PE">PE</option>
                            <option value="FTE">FTE</option>
                            <option value="Subcon">Subcon</option>
                            <option value="Consultant">Consultant</option>
                            <option value="Intern">Intern</option>
                            <option value="FTE to PE">FTE to PE</option>
                            <option value="Temping">Temping</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <span class="details">Ecode </span>
                        <input type="text" placeholder="04418" name="Ecode" id="Ecode">
                    </div>
                    <div class="input-box">
                        <span class="details">Employee First Name</span>
                        <input type="text" placeholder="First Name As Per PAN" name="Efname" id="Efname">
                    </div>
                    <div class="input-box">
                        <span class="details">Employee Middle Name</span>
                        <input type="text" placeholder="Middle Name As Per PAN" name="Emname" id="Emname">
                    </div>

                    <div class="input-box">
                        <span class="details">Employee Last Name</span>
                        <input type="text" placeholder="Last Name As Per PAN" name="Elname" id="Elname">
                    </div>


                    <div class="input-box">
                        <span class="details">Date of Joining</span>
                        <input type="date" placeholder="" id="Edoj" name="Edoj">
                    </div>
                    <div class="input-box">
                        <span class="details">Department</span>
                        <select name="Dept" id="Dept" class="" style="width:90%">

                            <?php echo $dept;?>

                        </select>
                    </div>
                    <div class="input-box">
                        <span class="details">Designation</span>
                        <select name="Desig" id="Desig" class="" style="width:90%">

                            <?php echo $desgn;?>

                        </select>
                    </div>
                    <div class="input-box">

                        <div class="input-box">
                            <span class="details">Location</span>
                            <select name="Location" id="Location" class="" style="width:90%">

                                <?php echo $location;?>

                            </select>
                        </div>

                    </div>

                    <div class="input-box">
                        <span class="details" for="Ecli">Client / Project</span>

                        <select name="Ecli" id="Ecli" class="" style="width:90%">

                            <?php echo $cli;?>

                        </select>
                    </div>
                    <div class="input-box">
                        <!-- <span class="details">RM </span>
                        <input type="number" placeholder="" id="Erm" name="Erm" > -->

                        <span class="details" for="Erm">Reporting Manager:</span>

                        <select name="Erm" id="Erm" class="" style="width:90%">

                            <?php echo $rm;?>

                        </select>
                    </div>
                    <div class="input-box">
                        <span class="details">Contact Number</span>
                        <input type="tel" placeholder="9699326182" id="Econ" name="Econ">
                    </div>
                    <div class="input-box">
                        <span class="details" for="Erect">Recruiter</span>

                        <select name="Erect" id="Erect" class="" style="width:90%">

                            <?php echo $rec;?>

                        </select>
                    </div>
                    <div class="input-box">
                        <span class="details">Grade</span>
                        <input type="text" placeholder="E20" id="Egra" name="Egra">
                    </div>
                    <div class="input-box">
                        <span class="details">Official Mail ID</span>
                        <input type="email" placeholder="neha@nseit.com" id="Eomail" name="Eomail">
                    </div>
                    <div class="input-box">
                        <span class="details">Personal Mail </span>
                        <input type="email" placeholder="nmishra@gmail.com" id="Epmail" name="Epmail">
                    </div>


                    <div class="input-box">
                        <span class="details">Pan Card </span>
                        <input type="text" placeholder="" id="Epan" name="Epan">
                    </div>
                    <div class="input-box">
                        <span class="details">Aadhar Card </span>
                        <input type="number" placeholder="" id="Eaadh" name="Eaadh">
                    </div>
                    <div class="input-box">
                        <span class="details">Date Of Birth</span>
                        <input type="date" placeholder="" id="Edob" name="Edob">
                    </div>

                    <div class="input-box">
                        <span class="details">Skills</span>
                        <input type="text" placeholder="Java , C" id="Eskills" name="Eskills">
                    </div>


                    <div class="input-box">
                        <span class="details">Previous Experience</span>
                        <input type="text" placeholder="Java , C" id="Epexp" name="Epexp">
                    </div>

                    <div class="input-box">
                        <span class="details">ESIC</span>
                        <input type="text" placeholder="Yes/No/NA" id="Eesic" name="Eesic">
                    </div>

                    <div class="input-box">
                        <span class="details">Qualification</span>
                        <input type="text" placeholder="BE / B.Sc" id="Equal" name="Equal">
                    </div>
                    <div class="input-box">
                        <span class="details">Role</span>
                        <input type="text" placeholder="Developer / Tester" id="Eroles" name="Eroles">
                    </div>


                </div>











                <div class="button">
                    <input type="button" id="submitjt" value="Submit">
                </div>
            </form>
        </div>
    </div>

</body>

<script src="JT.js"></script>

</html>
