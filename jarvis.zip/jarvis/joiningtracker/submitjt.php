<?php

session_start();

require("../config.php");

$Etype = filter_input(INPUT_POST, 'Etype', FILTER_SANITIZE_STRING);


$user = $_SESSION["username"];
$Ecode =$_POST["Ecode"];
$Edoj =$_POST["Edoj"];
$Efname =$_POST["Efname"];
$Emname =$_POST["Emname"];
$Elname =$_POST["Elname"];
$Edoj =$_POST["Edoj"];
// $Dept =$_POST["Dept"];
// $Desig =$_POST["Desig"];
// $Location =$_POST["Location"];
// $Ecli =$_POST["Ecli"];

$Erm = filter_input(INPUT_POST, 'Erm', FILTER_SANITIZE_STRING);
$Ecli = filter_input(INPUT_POST, 'Ecli', FILTER_SANITIZE_STRING);
$Dept = filter_input(INPUT_POST, 'Dept', FILTER_SANITIZE_STRING);
$Desig = filter_input(INPUT_POST, 'Desig', FILTER_SANITIZE_STRING);
$Location = filter_input(INPUT_POST, 'Location', FILTER_SANITIZE_STRING);
$Erect = filter_input(INPUT_POST, 'Erect', FILTER_SANITIZE_STRING);
$Econ =$_POST["Econ"];
$Egra =$_POST["Egra"];
$Eomail =$_POST["Eomail"];
$Epmail =$_POST["Epmail"];
$Epan =$_POST["Epan"];
$Eaadh =$_POST["Eaadh"];
$Edob =$_POST["Edob"];
$Eskills =$_POST["Eskills"];
$Epexp =$_POST["Epexp"];
$Eesic =$_POST["Eesic"];
$Equal =$_POST["Equal"];
$Eroles =$_POST["Eroles"];


// echo $Ecode;	
// echo $Edoj;	echo "\n" ; 
// echo $Efname;	echo "\n" ; 
// echo $Emname;	echo "\n" ; 
// echo $Elname;	echo "\n" ; 
// echo $Edoj;	echo "\n" ; 
// echo $Dept;	echo "\n" ; 
// echo $Desig;	echo "\n" ; 
// echo $Location;	echo "\n" ; 
// echo $Ecli;	echo "\n" ; 
// echo $Erm;	echo "\n" ; 
// echo $Econ;	echo "\n" ; 
// echo $Erect;	echo "\n" ; 
// echo $Egra;	echo "\n" ; 
// echo $Eomail;	echo "\n" ; 
// echo $Epmail;	echo "\n" ; 
// echo $Epan;	echo "\n" ; 
// echo $Eaadh;	echo "\n" ; 
// echo $Edob;	echo "\n" ; 


$sql = "INSERT INTO `jt` (`Etype`,`Ecode`, `Edoj`, `Efname`, `Emname`, `Elname`, `Dept`, `Desig`, `Location`, `Ecli`, `Erm`, `Econ`, `Erect`, `Egra`, `Eomail`, `Epmail`, `Epan`, `Eaadh`, `Edob`, `Eskills`, `Equal`, `Eesic`, `Eroles` , `Last Edited By`)  VALUES 
('$Etype',
'$Ecode',
'$Edoj',
'$Efname',
'$Emname',
'$Elname',
'$Dept',
'$Desig',
'$Location',
'$Ecli',
'$Erm',
'$Econ',
'$Erect',
'$Egra',
'$Eomail',
'$Epmail',
'$Epan',
'$Eaadh',
'$Edob',
'$Eskills',
'$Equal',
'$Eesic',
'$Eroles',

'$user' 
);" ;
       
       
    //  $sql2=  "INSERT INTO `jt` (`Ecode`, `Edoj`, `Efname`, `Emname`, `Elname`, `Dept`, `Desig`, `Location`, `Ecli`, `Erm`, `Econ`, `Erect`, `Egra`, `Eomail`, `Epmail`, `Epan`, `Eaadh`, `Edob`, `Eskills`, `Equal`, `Eesic`, `Eroles`) VALUES ('04418', '2022-04-01', 'Neha', 'Indeevar', 'Mishra', 'HRD', 'Developer', 'NSE', 'NSE', 'Richi', '9699326182', 'Sunil', 'E20', 'nehamishra@nseit.com', 'nmishra1309@gmail.com', 'DVZPD1234H', '449231242121', '2022-04-01', 'Flutter', 'BE', 'No', 'Developer');";
// Attempt insert query execution
if(mysqli_query($link, $sql)){
    echo '<script>alert("Data Updated Successfully.")</script>';
    header("location: index.php");

    sleep(3);



} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}


?>