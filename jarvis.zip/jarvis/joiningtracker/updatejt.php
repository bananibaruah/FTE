<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>NSE-IT</title>



    <!-- bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <!-- progress barstle -->
    <link rel="stylesheet" href="css/css-circular-prog-bar.css">
    <!-- fonts style -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <!-- font wesome stylesheet -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" />
    <!-- responsive style -->
    <link href="css/responsive.css" rel="stylesheet" />




    <link rel="stylesheet" href="css/css-circular-prog-bar.css">


</head>

<body>
    <div class="top_container">
        <!-- header section strats -->
        <header class="header_section">
            <div class="container">
                <nav class="navbar navbar-expand-custom navbar-mainbg">

                    <a class="navbar-brand navbar-logo" href="#"><img src="../images/nselogo.png" width="150px"
                            height="100px" alt=""><span></span></a>
                    <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-bars text-white"></i>
                    </button>

                    <a href="index.php" class="call_to-btn btn_white-border">
                        <span>
                            <b>HOME</b>
                        </span>
                        <img src="images/prev.png" alt="">
                    </a>
                    <div class=" navbar" id="navbarSupportedContent">

                        <!--a class="nav-link" href="javascript:void(0);"><i class="fas fa-tachometer-alt"></i>HOME</a>
            <a class="nav-link" href="javascript:void(0);"><i class="fas fa-tachometer-alt"></i>HOME</a-->

                    </div>
                </nav>

            </div>
        </header>
        <section class="hero_section ">
            <div class="hero-container container">

                <div class="hero_detail-box">
                    <h3>
                        <center>Update your Record</center> <br>

                    </h3>
                </div>
                <div class="hero_img-container">
                    <div>
                        <?php
// Include config file
require_once "../config.php";

// Define variables and initialize with empty values
$Edoj = $Efname = $Emname = $Elname = $Etype = $Dept = $Desig = $Location = $Ecli = $Erm = $Econ = $Erect = $Egra =
    $Eomail = $Epmail = $Epan = $Eaadh = $Edob = $Eskills = $Equal = $Eesic = $Eroles = "";
$Edoj_err = $Efname_err = $Emname_err = $Elname_err = $Etype = $Dept_err = $Desig_err = $Location_err = $Ecli_err =
    $Erm_err = $Econ_err = $Ercet_err = $Egra_err = $Eomail_err = $Epmail_err = $Epan_err = $Eaadh_err = $Edob_err =
    $Eskills_err = $Equal_err = $Eesic_err = $Eroles_err = "";

if (isset($_POST["id"]) && !empty($_POST["id"])) {
    // Get hidden input value
    $id = $_POST["id"];
    $Edoj = trim($_POST["nc"]);
    $Efname = trim($_POST["bc"]);
    $Emname = trim($_POST["rk"]);
    $Elname = trim($_POST["elname"]);
    $Etype = trim($_POST["etype"]);
    $Dept = trim($_POST["dept"]);
    $Desig = trim($_POST["desig"]);
    $Location = trim($_POST["location"]);
    $Ecli = trim($_POST["ecli"]);
    $Erm = trim($_POST["erm"]);
    $Econ = trim($_POST["econ"]);
    $Erect = trim($_POST["erect"]);
    $Egra = trim($_POST["egra"]);
    $Eomail = trim($_POST["eomail"]);
    $Epmail = trim($_POST["epmail"]);
    $Epan = trim($_POST["epan"]);
    $Eaadh = trim($_POST["eaadh"]);
    $Edob = trim($_POST["edob"]);
    $Eskills = trim($_POST["eskills"]);
    $Equal = trim($_POST["equal"]);
    $Eesic = trim($_POST["eesic"]);
    $Eroles = trim($_POST["eroles"]);

    // $salary = str_replace("'","\'",$salary);


    // $salary = str_replace("'","\'",$salary);

    // echo $Emname;


    // echo $name,$address,$salary;

    $link = mysqli_connect("localhost", "root", "mypass", "jarvis");

    // Check connection
    if ($link === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    $sql = "UPDATE jt SET Edoj = '$Edoj', Efname = '$Efname', Emname = '$Emname', Elname = '$Elname', Etype = '$Etype', Dept = '$Dept',
    Desig = '$Desig', Ecli = '$Ecli', Erm = '$Erm', Econ = '$Econ', Erect = '$Erect', Egra = '$Egra', Eomail = '$Eomail',
    Epmail = '$Epmail', Epan = '$Epan', Eaadh = '$Eaadh', Edob = '$Edob', Eskills = '$Eskills', Equal = '$Equal', Eesic = '$Eesic',
    Eroles = '$Eroles' WHERE Ecode = '$id';";

    // Attempt insert query execution
    if (mysqli_query($link, $sql)) {
        echo '<script>alert("Data Updated Successfully.")</script>';
        sleep(3);



    }
    else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

    // Close connection
    mysqli_close($link);



}
else {
    if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
        $id = trim($_GET["id"]);

        $sql = "SELECT * FROM jt WHERE Ecode = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_id);

            $param_id = $id;

            if (mysqli_stmt_execute($stmt)) {
                $result = mysqli_stmt_get_result($stmt);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

                    // Retrieve individual field value
                    $Edoj = $row["Edoj"];
                    $Efname = $row["Efname"];
                    $Emname = $row["Emname"];
                    $Elname = $row["Elname"];
                    $Etype = $row["Etype"];
                    $Dept = $row["Dept"];
                    $Desig = $row["Desig"];
                    $Location = $row["Location"];
                    $Ecli = $row["Ecli"];
                    $Erm = $row["Erm"];
                    $Econ = $row["Econ"];
                    $Erect = $row["Erect"];
                    $Egra = $row["Egra"];
                    $Eomail = $row["Eomail"];
                    $Epmail = $row["Epmail"];
                    $Epan = $row["Epan"];
                    $Eaadh = $row["Eaadh"];
                    $Edob = $row["Edob"];
                    $Eskills = $row["Eskills"];
                    $Equal = $row["Equal"];
                    $Eesic = $row["Eesic"];
                    $Eroles = $row["Eroles"];

                }
                else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }

            }
            else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);

        // Close connection
        mysqli_close($link);
    }
    else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
                        <link rel="stylesheet"
                            href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
                        <style>
                        .wrapper {
                            width: 600px;
                            margin: 0 auto;
                        }
                        </style>

                        <div class="wrapper">
                            <div class="container-fluid">
                                <div class="row">

                                    <div class="col-md-12">
                                        <h2 class="mt-5"></h2>
                                        <p>
                                        <h6>Please edit the input values and submit to update the employee record.</h6>
                                        </p>
                                        <form
                                            action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>"
                                            method="post">
                                            <div class="form-group">
                                                <label>Edoj</label>
                                                <input type="date" textarea name="nc"
                                                    class="form-control "><?php echo $Edoj; ?></input>
                                            </div>
                                            <div class="form-group">
                                                <label>Efname</label>
                                                <textarea name="bc"
                                                    class="form-control "><?php echo $Efname; ?></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label>Emname</label>
                                                <textarea name="rk"
                                                    class="form-control "><?php echo $Emname; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Elname</label>
                                                <textarea name="elname"
                                                    class="form-control "><?php echo $Elname; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Etype</label>
                                                <textarea name="etype"
                                                    class="form-control "><?php echo $Etype; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Dept</label>
                                                <textarea name="dept"
                                                    class="form-control "><?php echo $Dept; ?></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label>Desig</label>
                                                <textarea name="desig"
                                                    class="form-control "><?php echo $Desig; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Location</label>
                                                <textarea name="location"
                                                    class="form-control "><?php echo $Location; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Elic</label>
                                                <textarea name="ecli"
                                                    class="form-control "><?php echo $Ecli; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Erm</label>
                                                <textarea name="erm"
                                                    class="form-control "><?php echo $Erm; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Econ</label>
                                                <textarea name="econ"
                                                    class="form-control "><?php echo $Econ; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Erect</label>
                                                <textarea name="erect"
                                                    class="form-control "><?php echo $Erect; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Egra</label>
                                                <textarea name="egra"
                                                    class="form-control "><?php echo $Egra; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Eomail</label>
                                                <textarea name="eomail"
                                                    class="form-control "><?php echo $Eomail; ?></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label>Epmail</label>
                                                <textarea name="epmail"
                                                    class="form-control "><?php echo $Epmail; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Epan</label>
                                                <textarea name="epan"
                                                    class="form-control "><?php echo $Epan; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Eaadh</label>
                                                <textarea name="eaadh"
                                                    class="form-control "><?php echo $Eaadh; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Edob</label>
                                                <input type="date" textarea name="edob"
                                                    class="form-control "><?php echo $Edob; ?></input>
                                            </div>
                                            <div class="form-group">
                                                <label>Eskills</label>
                                                <textarea name="eskills"
                                                    class="form-control "><?php echo $Eskills; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Equal</label>
                                                <textarea name="equal"
                                                    class="form-control "><?php echo $Equal; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Eesic</label>
                                                <textarea name="eesic"
                                                    class="form-control "><?php echo $Eesic; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Eroles</label>
                                                <textarea name="eroles"
                                                    class="form-control "><?php echo $Eroles; ?></textarea>
                                            </div>


                                            <input type="hidden" name="id" value="<?php echo $id; ?>" />
                                            <input type="submit" class="btn btn-primary" value="Submit">
                                            <a href="viewjtasjt.php" class="btn btn-secondary ml-2">Cancel</a>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- end header section -->



    <end landing section -->




        <!-- footer section -->
        <section class="container-fluid footer_section">
            <p>
                NSE-IT &copy; 2022 All Rights Reserved By
            </p>
        </section>
        <!-- footer section -->

        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.js"></script>
        <!-- google map js -->
        <!-- end google map js -->
</body>

</html>